package com.example.lab2;
import android.os.StrictMode;
import android.widget.EditText;
import android.widget.TextView;

import java.net.URL;
import java.util.Scanner;
import android.os.Bundle;
import android.view.View;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.net.URL;
import java.util.Scanner;
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void displayCruises(View view) {
        EditText editFile = findViewById(R.id.edit_file);
        TextView textMain = findViewById(R.id.text_main);

        Cruise c1 = new Cruise();
        Cruise c2 = new Cruise();
        Cruise c3 = new Cruise();

        try {
            URL url = new URL(editFile.getText().toString().trim());
            Scanner in = new Scanner(url.openStream());

            readCruise(in, c1);
            readCruise(in, c2);
            readCruise(in, c3);
            in.close();
        } catch (Exception e) {
            textMain.setText("Error reading file: " + e.getMessage());
            return;
        }

        String output = cruiseText(c1) + cruiseText(c2) + cruiseText(c3);

        int totalDays = c1.getDays() + c2.getDays() + c3.getDays();
        double totalPrice = c1.getPrice() + c2.getPrice() + c3.getPrice();

        double avgLength = totalDays / 3.0;          // 3.0, not 3, so it's real division
        double avgPerDay = totalPrice / totalDays;

        output += String.format("Average length: %.1f days\n", avgLength);
        output += String.format("Average price per day: $%.2f", avgPerDay);

        textMain.setText(output);
    }

    private void readCruise(Scanner in, Cruise c) {
        c.setCruise_line(in.nextLine());
        c.setShip_name(in.nextLine());
        c.setCruise_code(in.nextLine());
        c.setDestination(in.nextLine());
        c.setDays(Integer.parseInt(in.nextLine().trim()));
        c.setPrice(Double.parseDouble(in.nextLine().trim()));
    }

    private String cruiseText(Cruise c) {
        return "Cruise line: " + c.getCruise_line() + "\n"
                + "Ship: " + c.getShip_name() + "\n"
                + "Code: " + c.getCruise_code() + "\n"
                + "Destination: " + c.getDestination() + "\n"
                + "Length: " + c.getDays() + " days\n"
                + String.format("Price: $%.2f\n\n", c.getPrice());
    }
}