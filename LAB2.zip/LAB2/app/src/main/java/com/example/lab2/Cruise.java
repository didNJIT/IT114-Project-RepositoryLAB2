package com.example.lab2;

public class Cruise {

    private String cruise_line;
    private String ship_name;
    private double price;
    private String cruise_code;
    private String destination;
    private int days;

    public String getCruise_line() {
        return cruise_line;
    }

    public void setCruise_line(String cruise_line) {
        this.cruise_line = cruise_line;
    }
    public String getShip_name() {
        return ship_name;
    }
    public void setShip_name(String ship_name) {
        this.ship_name = ship_name;
    }
    public double getPrice() {
        return price;
    }
    public void setPrice(double price) {
        this.price = price;
    }
    public String getCruise_code() { return cruise_code; }
    public void setCruise_code(String cruise_code) { this.cruise_code = cruise_code; }

    public String getDestination() { return destination; }
    public void setDestination(String destination) { this.destination = destination; }

    public int getDays() { return days; }
    public void setDays(int days) { this.days = days; }


}
